# Solarsystem
Kooperierendes OpenGL-Projekt zwischen Softwareentwicklung und Medientechnik.

Steuerung
---

| Taste(n) | Aktion                               |
| ---------|--------------------------------------|
| l        | Licht an/aus                         |
| t        | Texturen an/aus                      |
| p        | Animation an/aus                     |
| c        | Kameraposition ändern & zurücksetzen |
| w/s      | Animationen schneller/langsamer      |
| +/-      | Mehr/Weniger Zoom                    |

Teammitglieder
---
Daniel Herczeg
Astrid Krickl

![alt tag](http://i60.tinypic.com/2chq9a8.jpg)

powered by Python
